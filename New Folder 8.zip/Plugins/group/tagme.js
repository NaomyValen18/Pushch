module.exports= {
type: 'group',
command: ['tagme'],
operate: async (context) => {
const { client, xy, q:text, reply } = context;

let orang = (await client.groupMetadata(m.chat)).participants.map(u => u.jid)
let tag = `@${m.sender.replace(/@.+/, '')}`
let mentionedJid = [m.sender]
 client.sendMessage(m.chat,{text: tag},{ contextInfo: { mentionedJid }},{quoted:xy})
}
 }