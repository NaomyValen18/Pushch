//————————————————————————//

/*

Created By Xyroo
WhatsApp Me : 6281543496975

 - Source ↓
 - https://chat.whatsapp.com/B5eed04F4v6LbstG2SuRbA
 - https://whatsapp.com/channel/0029Vak9tFD2P59bOJcv3N3b
- https://whatsapp.com/channel/0029Valg4QU7oQhidANPik3Q
- https://whatsapp.com/channel/0029VajOwS32phHQj8bIpd3G

*/

//————————————————————————//


//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const Fichan = new require('./lib/functions')
const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\

//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\
// SETUP \\

// SYSTEM
global.prefa = ['','.'] 
global.usePairingCode = true

// Set Thumb url dan jpg
global.thumbX = "https://files.catbox.moe/4tx99f.jpg"
global.thumb = "https://files.catbox.moe/tg1pn1.jpg"
global.thumb1 = fs.readFileSync('./Media/image/lijaa.jpg');

// Set owner
global.ownername = 'XyrooRynzz'
global.owner = ['6281543496975']

// Set bot
global.bot = '62857742935943'
global.botname = 'ス  Lizaa MD'
global.version = '8.0.0'
global.lz = "🕐"
global.freelimit = 40
global.lz2 = '😂'
global.emojipick = ' ▢ '
global.runon = 'Panel'
global.baileys = 'whiskeysockets/baileys'

global.welcome = 'Selamat Datang 🖐'
global.left = 'Selamat Tinggal 👋'
global.soundwelcome = 'https://files.catbox.moe/4yt76r.mp3'
global.soundleft = 'https://files.catbox.moe/7v9s5p.mp3'
global.soundcool = 'https://files.catbox.moe/lrmym6.mp3'

// Set Sticker
global.packname = 'ス  Lizaa MD'
global.author = '© XyrooRynzz'

// Payment
global.dana = '085774293594'
global.danajpg = "https://files.catbox.moe/h9vyzb.jpg"
global.qris = "https://files.catbox.moe/gjrh98.jpg"
global.qrisjpg = 'https://files.catbox.moe/gjrh98.jpg'

// Source Url
global.groupbot = "https://chat.whatsapp.com/IJx5bkPvivUCeai7d2ChRC"
global.idgroup = "120363212737245798@g.us"
global.idch = "120363334489370893@newsletter"
global.idchtesti = "120363331578871714@newsletter"
global.yt = 'https://youtube.com/@XyrooRynzz'
global.ig = 'https://instagram.com/xyroorynzz'
global.xtele = 'https://t.me/XyrooRynzz'
global.channel = "https://whatsapp.com/channel/0029Vak9tFD2P59bOJcv3N3b"
global.chtesti = "https://whatsapp.com/channel/0029VamvtL2ADTO7ikBeNe1E"

// Send Notification
global.sendowner = `${botname} — Success Connect\n\nDeveloper Script: ${ownername}\nNama Bot: ${botname}\nVersi: ${version}`

global.textpanel = `*Bergaransi 20 day 1x replace*
 
- wa.me/6281543496975
- ${xtele}
- ${ig}

— Testimoni
${chtesti}`

// False/True
global.autoswview = true
global.autobio = false
global.anticall = true
global.setwelcome = true

// Settings Api Panel Pterodactyl
global.domain = 'https://xyryuprvtserver.rajaserver.biz.id'
global.apikeyplta = 'ptla_RFX7SOUgFwDC7u0mpGmKeNTTzdOlQLq0AAK173uboV1'
global.apikeypltc = 'ptlc_K4XbCOd5A3LTjgWKpOanRIPLKVIkfmXwZoMGC8DGbSo'
global.eggsnya = '16'
global.location = '1'

// Orkut Set Pnya lu sendiri
global.orkut = {
  key: '819715517366149482158086OKCT236D605A354300A63A890694FA720721',
  merchant: 'OK2158086',
  codeqr: '00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214508386628888070303UMI51440014ID.CO.QRIS.WWW0215ID20253689001840303UMI5204541153033605802ID5921XYROO STORE OK21580866013JAKARTA UTARA61051411062070703A016304D923'
}


// Batas Setup \\
//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\
//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\
// Apikey No Share, Share? Blacklist
global.key = 'SRA-MDBGFF'
global.apiauto = 'https://api.autoresbot.com'
global.apires = 'd79b5492b3e840d089939fcf'
global.apires2 = 'APIKEY_MIKUBOT'
global.apiend = 'https://endpoint.web.id'
global.apikey = 'APIKEY_YANTO'
global.apiwidipe = 'https://btch.us.kg'
global.btz = 'd7aL79aL'
global.botch = 'Zl4cNpTq'
global.beta = 'https://api.betabotz.eu.org'
global.botz = 'APIKEY_YUDZXML'

const api = {
  xterm: {
    url: "https://aihub.xtermai.xyz",
    key: "AIzaeAWCPw44TGUASdDR"
  }
};

//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\

//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\
//Rpg
global.rpg = {
emoticon(string) {
string = string.toLowerCase()
let emot = {
level: '📊',
limit: '🎫',
health: '❤️',
exp: '✨',
atm: '💳',
money: '💰',
bank: '🏦',
potion: '🥤',
diamond: '💎',
common: '📦',
uncommon: '🛍️',
mythic: '🎁',
legendary: '🗃️',
superior: '💼',
pet: '🔖',
trash: '🗑',
armor: '🥼',
sword: '⚔️',
pickaxe: '⛏️',
fishingrod: '🎣',
wood: '🪵',
rock: '🪨',
string: '🕸️',
horse: '🐴',
cat: '🐱',
dog: '🐶',
fox: '🦊',
robo: '🤖',
petfood: '🍖',
iron: '⛓️',
gold: '🪙',
emerald: '❇️',
upgrader: '🧰',
bibitanggur: '🌱',
bibitjeruk: '🌿',
bibitapel: '☘️',
bibitmangga: '🍀',
bibitpisang: '🌴',
anggur: '🍇',
jeruk: '🍊',
apel: '🍎',
mangga: '🥭',
pisang: '🍌',
botol: '🍾',
kardus: '📦',
kaleng: '🏮',
plastik: '📜',
gelas: '🧋',
chip: '♋',
umpan: '🪱',
skata: '🧩'
}
let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
if (!results.length) return ''
else return emot[results[0][0]]
}
}
//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\

//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Succes Update : '${__filename}'`))
	delete require.cache[file]
	require(file)
})
//≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠\\