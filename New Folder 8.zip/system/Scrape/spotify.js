const axios = require('axios')
const chalk = require('chalk')
const cheerio = require("cheerio")
const FormData = require('form-data')
const fs = require('fs')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const path = require('path')

async function spotifySearch(query) {
  try {
    const access_token = await getAccessToken()
    const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=10`, {
      headers: {
        Authorization: `Bearer ${access_token}`
      }
    })
    return response.data.tracks.items.map(track => ({
      name: track.name,
      artists: track.artists.map(artist => artist.name).join(', '),
      link: track.external_urls.spotify,
      image: track.album.images[0].url,
      duration_ms: track.duration_ms
    }));
  } catch (err) {
    console.error(err)
  }
}

async function spotifyDl(url) {
  try {
    const hai = await axios.get(`https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`)
    const hao = await axios.get(`https://api.fabdl.com/spotify/mp3-convert-task/${hai.data.result.gid}/${hai.data.result.id}`)
    return {
      title: hai.data.result.name,
      download: `https://api.fabdl.com${hao.data.result.download_url}`,
      image: hai.data.result.image,
      duration_ms: hai.data.result.duration_ms
    }
  } catch (err) {
    console.error(err)
  }
}

module.exports = {
  spotifySearch,
  spotifyDl
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)})