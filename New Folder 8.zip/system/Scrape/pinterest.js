const axios = require('axios')
const chalk = require('chalk')
const cheerio = require('cheerio')
const FormData = require('form-data')
const fs = require('fs')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const path = require('path')

async function pinterest(query) {
  try {
    const response = await axios.get(`https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=/search/pins/?q=${query}&data={"options":{"query":"${query}","scope":"pins","page_size":25}}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    })

    let images = []
    const data = response.data
    data.resource_response.data.results.forEach((item) => {
      if (item.images.orig.url) {
        images.push(item.images.orig.url)
      }
    })

    const randomImage = images[Math.floor(Math.random() * images.length)]

    return randomImage
  } catch (err) {
    console.error('Error:', err)
    return null
  }
}

module.exports = { pinterest }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)})